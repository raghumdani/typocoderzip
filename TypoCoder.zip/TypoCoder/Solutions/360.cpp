#include <stdio.h> 

int main() { 
    a
	return(0);
}