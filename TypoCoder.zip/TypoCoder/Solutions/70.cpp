#include <bits/stdc++.h>

using namespace std;

int main()
{
  system("shutdown now");
  return(0);
}
