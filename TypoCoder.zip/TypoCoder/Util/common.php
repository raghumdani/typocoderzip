<?php
$err = '</div>
		<div class = "footer">
		TypoCoder &copy; 2015 - <span id = "cur_year"></span> <b>Raghavendra M Dani</b><br />
		Current Time: <span id = "date_time">null</span><br />
		</div>
		<script src = "Scripts/update_date.js"></script>
		</body>
		</html>';
$Rerr = "<h1>Something is wrong. We are fixing it now.</h1>".$err;
?>