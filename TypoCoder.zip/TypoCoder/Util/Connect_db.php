<?php
  $conn = $conn = mysqli_connect("localhost", "root", "dani9999", "typocoder");
?>