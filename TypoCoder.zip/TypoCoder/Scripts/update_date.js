var y = document.getElementById("cur_year");
var tim = document.getElementById("date_time");

var date = new Date();
y.innerHTML = date.getFullYear();
tim.innerHTML = date;